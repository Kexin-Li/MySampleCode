package org.bbs.dao;

import org.bbs.entity.Board;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.junit.Assert.*;

/**
 * BoardDao 对应的实体类
 * Created by Kexin_Li on 2017/2/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring/spring-dao.xml"})
public class BoardDaoTest {

    @Autowired
    private BoardDao boardDao;

    @Test
    public void addBoard() throws Exception {

    }

    @Test
    public void listAllBoard() throws Exception {
        List<Board> boards = boardDao.listAllBoard();
        for (Board board : boards) {
            System.out.println(board);
        }
    }

    @Test
    // 写好了 postDAO 再测试
    public void listAllPostsOfBoard() throws Exception {
        Board board = boardDao.listAllPostsOfBoard(1000);
        System.out.println(board);
    }

    @Test
    public void findBoardByBoardId() throws Exception {
        Board board = boardDao.findBoardByBoardId(1000);
        System.out.println(board);
    }

    @Test
    public void findBoardByBoardName() throws Exception {
        Board board = boardDao.findBoardByBoardName("funny");
        System.out.println(board);
    }

    @Test
    public void updateBoardByBoard() throws Exception {
        Board board = new Board();
        board.setBoardName("nothing");
        board.setBoardDesc("just test");
        board.setBoardPostNum(20);
        board.setBoardId(1001);
        boardDao.updateBoardByBoard(board);
        System.out.println(board);
    }

    @Test
    public void deleteBoardById() throws Exception {
        boardDao.deleteBoardById(1001);
    }

}