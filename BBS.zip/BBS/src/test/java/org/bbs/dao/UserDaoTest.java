package org.bbs.dao;

import org.bbs.entity.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

/**
 * UserDao 对应的测试类
 * Created by Kexin_Li on 2017/2/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring/spring-dao.xml"})
public class UserDaoTest {

    @Autowired
    private UserDao userDao;

    @Test
    /**
     * User{userId=1,
     * userName=kite,
     * password=null,
     * userPhone=13077998800,
     * userEmail=123@gmail.com,
     * userSex=girl,
     * createTime=2017-02-18 18:18:02.0,
     * userType=1, userState=0,
     * lastLoginTime=2017-02-09 00:00:00.0, lastIp=123.0.0.1}
     */
    public void findUserByUserName() throws Exception {
        User user = userDao.findUserByUserName("kite");
        System.out.println(user);
    }

    @Test
    public void findUserByUserId() throws Exception {
        User user = userDao.findUserByUserId(1);
        System.out.println(user);
    }

    @Test
    public void addUser() throws Exception {
        User user = new User();
        user.setUserId(2);
        user.setUserName("tom");
        user.setPassword("000");
        user.setUserEmail("tom@gmail.com");
        user.setUserSex("boy");
//        user.setUserPhone();
        user.setUserType(0);
        user.setUserState(1);
        user.setCredit(100);
        Date nowTime = new Date();
        user.setLastLoginTime(nowTime);
        user.setLastIp("120.1.1.0");
        userDao.addUser(user);
        System.out.println(user);
    }

    @Test
    public void deleteUserByUserName() throws Exception {
        userDao.deleteUserByUserName("tom");
    }

    @Test
    /*此方法有问题*/
    public void updateUserByUserName() throws Exception {
        User user = new User();
        user.setPassword("000");
        user.setUserEmail("tom@gmail.com");
        user.setUserSex("boy");
        user.setUserPhone(1300000111);
        user.setUserType(0);
        user.setUserState(1);
        user.setCredit(100);
        Date nowTime = new Date();
        user.setLastLoginTime(nowTime);
        user.setLastIp("120.1.1.0");
        userDao.updateUserByUserName(user);
    }

    @Test
    public void getUserPasswordByUserName() throws Exception {
        System.out.println(userDao.getUserPasswordByUserName("kite"));
    }

    @Test
    public void getAllUserInfo() throws Exception {
        List<User> users = userDao.getAllUserInfo();
        for (User user : users) {
            System.out.println(user);
        }
    }

}