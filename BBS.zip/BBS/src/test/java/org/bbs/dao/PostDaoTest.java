package org.bbs.dao;

import org.bbs.entity.Post;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

/**
 * PostDao 对应的测试类
 * Created by Kexin_Li on 2017/2/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring/spring-dao.xml"})
public class PostDaoTest {

    @Autowired
    private PostDao postDao;

    @Test
    public void addPost() throws Exception {

    }

    @Test
    // TimeStamp error
    public void findPostByPostId() throws Exception {
        Post post = postDao.findPostByPostId(1001);
        System.out.println(post);
    }

    @Test
    /**
     * SQLErrorCodes loaded: [DB2, Derby, H2, HSQL, Informix, MS-SQL, MySQL, Oracle, PostgreSQL, Sybase, Hana]

     org.springframework.dao.TransientDataAccessResourceException:
     Error attempting to get column 'post_update_time' from result set.
     Cause: java.sql.SQLException:
     Value '1000zhangsan第一条帖子*大家好，这是我的第一条帖子。000002017-02-09 00:00:000000-00-00 00:00:00                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ' can not be represented as java.sql.Timestamp
     ; SQL []; Value '1000zhangsan第一条帖子*大家好，这是我的第一条帖子。000002017-02-09 00:00:000000-00-00 00:00:00                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ' can not be represented as java.sql.Timestamp; nested exception is java.sql.SQLException: Value '1000zhangsan第一条帖子*大家好，这是我的第一条帖子。000002017-02-09 00:00:000000-00-00 00:00:00                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ' can not be represented as java.sql.Timestamp
        TODO
     */
    public void listAllPostInfo() throws Exception {
        List<Post> posts = postDao.listAllPostInfo();
        for (Post post : posts) {
            System.out.println(post);
        }
    }

    @Test
    public void deletePostById() throws Exception {
        postDao.deletePostById(1000);
    }

    @Test
    public void updatePostByPost() throws Exception {
        Post post = new Post();
        post.setPostReplyCount(1);
        post.setPostId(1001);
       postDao.updatePostByPost(post);
    }

}