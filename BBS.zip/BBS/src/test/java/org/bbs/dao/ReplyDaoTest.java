package org.bbs.dao;

import org.bbs.entity.Reply;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.junit.Assert.*;

/**
 * ReplyDao 对应的测试类
 * Created by Kexin_Li on 2017/2/19.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring/spring-dao.xml"})
public class ReplyDaoTest {

    @Autowired
    private ReplyDao replyDao;

    @Test
    public void addReply() throws Exception {

    }

    @Test
    public void listReplyByPostId() throws Exception {
        List<Reply> replies = replyDao.listReplyByPostId(1001);
        for (Reply reply : replies) {
            System.out.println(reply);
        }
    }

    @Test
    public void deleteReplyById() throws Exception {
        replyDao.deleteReplyById(1000);
    }

    @Test
    public void findReplyByReplyId() throws Exception {

    }

}