package org.bbs.dao;

import org.bbs.entity.UserLoginLog;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

/**
 * UserLoginLogDao 对应的测试类
 * Created by Kexin_Li on 2017/2/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring/spring-dao.xml"})
public class UserLoginLogDaoTest {

    @Autowired
    private UserLoginLogDao userLoginLogDao;

    @Test
    public void listAllUserLoginLog() throws Exception {
        List<UserLoginLog> userLoginLogs = userLoginLogDao.listAllUserLoginLog();
        for (UserLoginLog userLoginLog : userLoginLogs) {
            System.out.println(userLoginLog);
        }
    }

    @Test
    public void addUserLoginLog() throws Exception {
        UserLoginLog userLoginLog = new UserLoginLog();
        Date now = new Date();
        userLoginLog.setLoginDateTime(now);
        userLoginLog.setUserName("hello");
        userLoginLog.setLoginIp("5.6.7.8");
        userLoginLogDao.addUserLoginLog(userLoginLog);
    }

}