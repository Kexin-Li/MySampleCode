package org.bbs.service.impl;

import org.bbs.entity.User;
import org.bbs.service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.*;

/**
 * UserService 对应的测试类
 * Created by Kexin_Li on 2017/2/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring/spring-dao.xml",
                        "classpath:spring/spring-service.xml"})
public class UserServiceImplTest {

    @Autowired
    private UserService userService;

    @Test
    public void addUser() throws Exception {

    }

    @Test
    public void updateUserByUserName() throws Exception {

    }

    @Test
    public void getUserByUserName() throws Exception {
        User user = userService.getUserByUserName("kite");
        System.out.println(user);
    }

    @Test
    public void deleteUserByUserName() throws Exception {

    }

    @Test
    public void loginSuccess() throws Exception {

    }

    @Test
    public void getPassword() throws Exception {

    }

    @Test
    public void getAllUser() throws Exception {

    }

}