package org.bbs.dao;

import org.bbs.entity.Post;

import java.util.List;

/**
 * 实体类 Post 对应的 DAO 接口
 * Created by Kexin_Li on 2017/2/18.
 */
public interface PostDao {

    /**
     * 添加帖子
     * @param post
     */
    void addPost(Post post);

    /**
     * 通过id查找帖子
     * @param postId
     * @return
     */
    Post findPostByPostId(int postId);

    /**
     * 列出全部主题信息
     * @return
     */
    List<Post> listAllPostInfo();

    /**
     * 删除帖子
     * @param postId
     */
    void deletePostById(int postId);

    /**
     * 更新主题信息
     * @param post
     */
    void updatePostByPost(Post post);

}
