package org.bbs.dao;

import org.bbs.entity.UserLoginLog;

import java.util.List;

/**
 * 实体类 UserLoginLog 对应的 DAO 接口
 * Created by Kexin_Li on 2017/2/18.
 */
public interface UserLoginLogDao {

    /**
     * 列出所有用户登录信息
     * @return
     */
    List<UserLoginLog> listAllUserLoginLog();

    /**
     * 插入用户登录信息
     * @param userLoginLog
     */
    void addUserLoginLog(UserLoginLog userLoginLog);

}
