package org.bbs.dao;

import org.bbs.entity.Board;

import java.util.List;

/**
 * 实体类 Board 对应的 DAO 接口
 * Created by Kexin_Li on 2017/2/18.
 */
public interface BoardDao {

    /**
     * 添加新板块
     * @param board
     */
    void addBoard(Board board);

    /**
     * 显示论坛所有板块
     * @return
     */
    List<Board> listAllBoard();

    /**
     * 显示板块中的帖子
     * @param boardId
     * @return
     */
    Board listAllPostsOfBoard(int boardId);

    /**
     * 通过id查找板块
     * @param boardId
     * @return
     */
    Board findBoardByBoardId(int boardId);

    /**
     * 通过名称查找板块
     * @param boardName
     * @return
     */
    Board findBoardByBoardName(String boardName);

    /**
     * 更新板块数据
     * @param board
     */
    void updateBoardByBoard(Board board);

    /**
     * 通过id删除板块
     * @param boardId
     */
    void deleteBoardById(int boardId);

}
