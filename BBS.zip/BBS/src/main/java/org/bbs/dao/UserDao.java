package org.bbs.dao;

import org.bbs.entity.User;

import java.util.List;

/**
 * 实体类 User 对应的 DAO 接口
 * Created by Kexin_Li on 2017/2/18.
 */
public interface UserDao {

    /**
     * 通过用户名称查找用户
     * @param username
     * @return
     */
    User findUserByUserName(String username);

    /**
     * 通过用户 id 查找用户
     * @param id
     * @return
     */
    User findUserByUserId(int id);

    /**
     * 插入用户信息
     * @param user
     */
    void addUser(User user);

    /**
     * 通过用户名称删除用户
     * @param username
     */
    void deleteUserByUserName(String username);

    /**
     * 更新用户
     * @param user
     */
    void updateUserByUserName(User user);

    /**
     * 通过用户名称获取用户密码
     * @param username
     * @return
     */
    String getUserPasswordByUserName(String username);

    /**
     * 获取用户所有信息
     * @return
     */
    List<User> getAllUserInfo();

}
