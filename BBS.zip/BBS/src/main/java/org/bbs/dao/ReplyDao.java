package org.bbs.dao;

import org.bbs.entity.Reply;

import java.util.List;

/**
 * 实体类 Reply 对应的 DAO 接口
 * Created by Kexin_Li on 2017/2/18.
 */
public interface ReplyDao {

    /**
     * 添加回复
     * @param reply
     */
    void addReply(Reply reply);

    /**
     * 显示所有回复
     * @param postId
     * @return
     */
    List<Reply> listReplyByPostId(int postId);

    /**
     * 删除回复
     * @param postId
     */
    void deleteReplyById(int postId);

    /**
     * 通过回复id查找回复
     * @param replyId
     * @return
     */
    Reply findReplyByReplyId(int replyId);

}
