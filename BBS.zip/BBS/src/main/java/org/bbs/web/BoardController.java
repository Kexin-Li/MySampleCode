package org.bbs.web;

import org.bbs.entity.Board;
import org.bbs.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

/**
 * BoardService 控制器
 * Created by Kexin_Li on 2017/2/19.
 */
@Controller
@RequestMapping(value = "/board")
public class BoardController {

    @Autowired
    private BoardService boardService;

    /**
     * 显示相应板块的帖子 @PathVariable
     * @param boardId
     * @param request
     * @return
     */
    @RequestMapping(value = "/listPosts-{boardId}")
    public String intoBoard(@PathVariable  int boardId, HttpServletRequest request) {
        Board board = boardService.intoBoardByBoardId(boardId);
        request.setAttribute("board", board);
        request.setAttribute("boardId", boardId);
        return "post/postMain";
    }

}
