package org.bbs.web;

import org.bbs.entity.User;
import org.bbs.entity.UserLoginLog;
import org.bbs.service.LoginLogService;
import org.bbs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.util.Date;

/**
 * UserService 控制器
 * Created by Kexin_Li on 2017/2/18.
 */
@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private LoginLogService loginLogService;

    /**
     * 用户登录
     * @param loginUser
     * @param request
     * @param attributes
     * @return
     */
    @RequestMapping(value = "/userLogin", method = RequestMethod.POST)
    public String userLogin(User loginUser, HttpServletRequest request, RedirectAttributes attributes) {
        // 通过用户名查找 User 对象
        User user = userService.getUserByUserName(loginUser.getUserName());
        String password = "";
        if (user != null) {
            password = userService.getPassword(user.getUserName());
        }

        // 判断登录信息是否正确
        if (user != null && loginUser.getPassword().equals(password)) {
            // 获取基本登录信息
            String lastIp = request.getRemoteAddr();
            String userName = user.getUserName();
            Timestamp lastLoginTime = new Timestamp(new Date().getTime());

            // 更新用户信息
            user.setLastIp(lastIp);
            user.setLastLoginTime(lastLoginTime);
            user.setCredit(5 + user.getCredit());
            userService.updateUserByUserName(user);

            // 更新用户登录日志
            UserLoginLog userLoginLog = new UserLoginLog();
            userLoginLog.setUserName(userName);
            userLoginLog.setLoginIp(lastIp);
            userLoginLog.setLoginDateTime(lastLoginTime);
            loginLogService.addUserLoginLog(userLoginLog);

            // 登陆成功，跳转到主页
            request.getSession().setAttribute("username", user.getUserName());
            return "redirect:/main";
        }
        // 登录失败，跳转页面
        request.setAttribute("Msg", "登录失败");
        return "error";
    }

    /**
     * 用户注册
     * @param userRegister
     * @param request
     * @return
     */
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String userRegister(User userRegister, HttpServletRequest request) {
        if (userRegister != null) {
            try {
                String username = userRegister.getUserName();
                String ip = request.getRemoteAddr();

                // 如果数据库中没有该用户，可以注册，否则跳转页面
                if (userService.getUserByUserName(username) == null) {
                    // 添加用户
                    userRegister.setLastIp(ip);
                    Timestamp createLoginTime = new Timestamp(new Date().getTime());
                    userRegister.setCreateTime(createLoginTime);
                    userRegister.setLastLoginTime(createLoginTime);
                    userService.addUser(userRegister);

                    // 添加用户登录日志
                    UserLoginLog userLoginLog = new UserLoginLog();
                    userLoginLog.setUserName(username);
                    userLoginLog.setLoginIp(ip);
                    userLoginLog.setLoginDateTime(createLoginTime);
                    loginLogService.addUserLoginLog(userLoginLog);

                    // 注册成功跳转
                    request.setAttribute("username", username);
                    return "index";
                } else {
                    request.setAttribute("Msg", "注册失败，用户名已被占用！");
                    return "error";
                }
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("Msg", "发生未知错误！");
                return "error";
            }
        }
        request.setAttribute("Msg", "发生未知错误！");
        return "error";
    }

    /**
     * 显示个人信息
     * @param username
     * @param request
     * @return
     */
    @RequestMapping(value ="/listUserInfo")
    public String listUserInfo(String username, HttpServletRequest request) {
        User user = userService.getUserByUserName(username);
        request.setAttribute("user", user);
        return "user/userInfo";
    }

    /**
     * 修改个人信息页面
     * @param username
     * @param request
     * @return
     */
    @RequestMapping(value = "/userUpdateInfo", method = RequestMethod.GET)
    public String userUpdateInfoPage(String username, HttpServletRequest request) {
        User user = userService.getUserByUserName(username);
        request.setAttribute("user", user);
        return "user/userUpdateInfo";
    }

    /**
     * 提交用户修改信息
     * @param user
     * @param attributes
     * @return
     */
    @RequestMapping(value = "/updateUserInfo", method = RequestMethod.POST)
    public String updateUserInfo(User user, RedirectAttributes attributes) {
        User newUser = user;
        userService.updateUserByUserName(user);
        attributes.addAttribute("username", newUser.getUserName());
        return "redirect:listUserInfo";
    }

    /**
     * 用户注销功能
     * @param request
     * @return
     */
    @RequestMapping(value = "/loginOut")
    public String loginOut(HttpServletRequest request) {
        request.getSession().removeAttribute("username");
        return "index";
    }

}
