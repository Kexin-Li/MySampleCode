package org.bbs.web;

import org.bbs.entity.Board;
import org.bbs.entity.Post;
import org.bbs.entity.User;
import org.bbs.service.BoardService;
import org.bbs.service.PostService;
import org.bbs.service.ReplyService;
import org.bbs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 管理员
 * Created by Kexin_Li on 2017/2/19.
 */
@Controller
@RequestMapping(value = "/admin")
public class AdminController {

    @Autowired
    BoardService boardService;

    @Autowired
    UserService userService;

    @Autowired
    PostService postService;

    @Autowired
    ReplyService replyService;

    /**
     * 论坛管理中心
     * @param request
     * @return
     */
    @RequestMapping(value = "/manageCenter")
    public String managerCenter(HttpServletRequest request) {
        if (request.getSession().getAttribute("username").equals("admin")) {
            return "admin/manageCenter";
        }
        return "redirect:/error";
    }

    /**
     * 论坛版块管理中心
     * @param request
     * @return
     */
    @RequestMapping(value = "/manageBoard")
    public String managerBoard(HttpServletRequest request) {
        if (request.getSession().getAttribute("username").equals("admin")) {
            List<Board> boards = boardService.listAllBoard();
            request.setAttribute("boards", boards);
            return "admin/manageBoard";
        }
        return "redirect:/error";
    }

    /**
     * 添加论坛板块
     * @param board
     * @param request
     * @return
     */
    @RequestMapping(value = "addBoard", method = RequestMethod.POST)
    public String addBoard(Board board, HttpServletRequest request) {
        if (board != null) {
            boardService.addBoardByBoard(board);
            return "redirect:/admin/manageBoard";
        }
        request.getSession().setAttribute("Msg", "添加板块出错！");
        return "admin/error";
    }

    /**
     * 修改板块信息
     * @param board
     * @param request 从 post 改成 get 就没有报错了
     * @return
     */
    @RequestMapping(value = "updateBoard", method = RequestMethod.GET)
    public String updateBoard(Board board, HttpServletRequest request) {
        if (board != null) {
            boardService.updateBoardInfo(board);
            return "redirect:/admin/manageBoard";
        }
        return "redirect:/error";
    }

    /**
     * 管理用户信息
     * @param request
     * @return
     */
    @RequestMapping(value = "manageUser")
    public String manageUser(HttpServletRequest request) {
        List<User> users = userService.getAllUser();
        if (users != null) {
            request.setAttribute("users", users);
            return "/admin/allUserInfo";
        }
        return "redirect:/error";
    }

    /**
     * 管理发表的主题
     * @param request
     * @return
     */
    @RequestMapping(value = "managePost")
    public String managePost(HttpServletRequest request) {
        List<Post> posts = postService.listAllPost();
        if (posts != null) {
            request.setAttribute("posts", posts);
            return "/admin/allPostInfo";
        }
        return "redirect:/error";
    }

    /**
     * 删除已经发表的主题
     * @param postId
     * @param postBoardId
     * @return
     */
    @RequestMapping(value = "deletePost")
    public String deletePost(int postId, int postBoardId) {
        postService.deletePost(postId);
        return "redirect:/board/listPosts-" + postBoardId;
    }

    /**
     * 删除回复
     * @param replyId
     * @param replyPostId
     * @return
     */
    @RequestMapping(value = "deleteReply")
    public String deleteReply(int replyId, int replyPostId) {
        replyService.deleteReply(replyId);
        return "redirect:/post/postContent-" + replyPostId;
    }

    /**
     * 删除板块
     * @param boardId
     * @return
     */
    @RequestMapping(value = "deleteBoard")
    public String deleteBoard(int boardId) {
        boardService.deleteBoard(boardId);
        return "redirect:manageBoard";
    }

}
