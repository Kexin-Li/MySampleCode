package org.bbs.service;

import org.bbs.entity.UserLoginLog;

/**
 * LoginLogDao 对应的 service 接口
 * Created by Kexin_Li on 2017/2/19.
 */
public interface LoginLogService {

    /**
     * 列出所有用户登录信息
     */
    void listAllUserLoginLog();

    /**
     * 插入用户登录信息
     * @param userLoginLog
     */
    void addUserLoginLog(UserLoginLog userLoginLog);

}
