package org.bbs.service.impl;

import org.bbs.dao.UserDao;
import org.bbs.entity.User;
import org.bbs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * UserService 接口的实现类
 * Created by Kexin_Li on 2017/2/18.
 */
@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserDao userDao;

    public void addUser(User user) {
        if (user != null) {
            userDao.addUser(user);
        }
    }

    public void updateUserByUserName(User user) {
        if (user != null) {
            userDao.updateUserByUserName(user);
        }
    }

    public User getUserByUserName(String userName) {
        if (userName == null) {
            return null;
        }
        return userDao.findUserByUserName(userName);
    }

    public void deleteUserByUserName(String userName) {
        userDao.deleteUserByUserName(userName);
    }

    public void loginSuccess(User user) {

    }

    public String getPassword(String userName) {
        if (userName == null) {
            return null;
        }
        return userDao.getUserPasswordByUserName(userName);
    }

    public List<User> getAllUser() {
        return userDao.getAllUserInfo();
    }
}
