package org.bbs.service;

import org.bbs.entity.Reply;

import java.util.List;

/**
 * ReplyDao 对应的 service 接口
 * Created by Kexin_Li on 2017/2/19.
 */
public interface ReplyService {

    /**
     * 回帖
     * @param reply
     */
    void addReply(Reply reply);

    /**
     * 显示所有回复
     * @param postId
     * @return
     */
    List<Reply> listReplyByPostId(int postId);

    /**
     * 删除回复
     * @param replyId
     */
    void deleteReply(int replyId);

}
