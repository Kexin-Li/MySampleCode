package org.bbs.service;

import org.bbs.entity.User;

import java.util.List;

/**
 * UserDao 对应的 Service 接口
 * Created by Kexin_Li on 2017/2/18.
 */
public interface UserService {

    /**
     * 添加用户
     * @param user
     */
    void addUser(User user);

    /**
     * 更新用户
     * @param user
     */
    void updateUserByUserName(User user);

    /**
     * 查询用户
     * @param userName
     * @return
     */
    User getUserByUserName(String userName);

    /**
     * 删除用户
     * @param userName
     */
    void deleteUserByUserName(String userName);

    /**
     *
     * @param user
     */
    void loginSuccess(User user);

    /**
     * 通过用户名得到密码
     * @param userName
     * @return
     */
    String getPassword(String userName);

    /**
     * 查询所有用户
     * @return
     */
    List<User> getAllUser();

}
