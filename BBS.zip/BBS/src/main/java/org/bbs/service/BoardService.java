package org.bbs.service;

import org.bbs.entity.Board;

import java.util.List;

/**
 * BoardDao 对应的 service 接口
 * Created by Kexin_Li on 2017/2/19.
 */
public interface BoardService {

    /**
     * 添加新板块
     * @param board
     */
    void addBoardByBoard(Board board);

    /**
     * 通过版块名删除板块
     * @param boardName
     */
    void deleteBoardByBoardName(String boardName);

    /**
     * 显示论坛所有板块
     * @return
     */
    List<Board> listAllBoard();

    /**
     * 显示板块中的帖子
     * @param boardId
     * @return
     */
    Board listAllPostOfBoard(int boardId);

    /**
     * 通过id插入新版块
     * @param boardId
     * @return
     */
    Board intoBoardByBoardId(int boardId);

    /**
     * 通过名称插入新版块
     * @param boardName
     * @return
     */
    Board intoBoardByBoardName(String boardName);

    /**
     * 更新帖子数
     * @param boardId
     */
    void updatePostNum(int boardId);

    /**
     * 更新板块数据
     * @param board
     */
    void updateBoardInfo(Board board);

    /**
     * 删除版块
     * @param boardId
     */
    void deleteBoard(int boardId);

}
