package org.bbs.service;

import org.bbs.entity.Post;

import java.util.List;

/**
 * PostDao 对应的 service 接口
 * Created by Kexin_Li on 2017/2/19.
 */
public interface PostService {

    /**
     * 发帖
     * @param post
     */
    void addPostByPost(Post post);

    /**
     * 通过id查找帖子
     * @param postId
     * @return
     */
    Post listPostContent(int postId);

    /**
     * 显示所有帖子
     * @return
     */
    List<Post> listAllPost();

    /**
     * 删帖
     * @param postId
     */
    void deletePost(int postId);

}
