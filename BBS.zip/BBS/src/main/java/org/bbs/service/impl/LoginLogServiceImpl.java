package org.bbs.service.impl;

import org.bbs.dao.UserLoginLogDao;
import org.bbs.entity.UserLoginLog;
import org.bbs.service.LoginLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * LoginLogService 的实现类
 * Created by Kexin_Li on 2017/2/19.
 */
@Service
public class LoginLogServiceImpl implements LoginLogService{

    @Autowired
    UserLoginLogDao userLoginLogDao;

    public void listAllUserLoginLog() {
        List<UserLoginLog> userLoginLogs = userLoginLogDao.listAllUserLoginLog();
    }

    public void addUserLoginLog(UserLoginLog userLoginLog) {
        userLoginLogDao.addUserLoginLog(userLoginLog);
    }

}
