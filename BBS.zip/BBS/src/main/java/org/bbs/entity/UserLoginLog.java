package org.bbs.entity;

import java.util.Date;

/**
 * 数据库表 t_login_log 对应的实体类
 * Created by Kexin_Li on 2017/2/18.
 */
public class UserLoginLog {

    // 登录日志属性
    private int loginLogId;
    private String userName;
    private String loginIp;
    private Date loginDateTime;

    private User user;

    public int getLoginLogId() {
        return loginLogId;
    }

    public void setLoginLogId(int loginLogId) {
        this.loginLogId = loginLogId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getLoginIp() {
        return loginIp;
    }

    public void setLoginIp(String loginIp) {
        this.loginIp = loginIp;
    }

    public Date getLoginDateTime() {
        return loginDateTime;
    }

    public void setLoginDateTime(Date loginDateTime) {
        this.loginDateTime = loginDateTime;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "UserLoginLogDao{" +
                "LoginLogId=" + loginLogId +
                ", UserName=" + userName +
                ", LoginIp=" + loginIp +
                ", LoginDateTime=" + loginDateTime + "}";
    }

}
